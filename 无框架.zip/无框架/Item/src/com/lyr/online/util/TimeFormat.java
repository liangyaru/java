package com.lyr.online.util;

import java.text.SimpleDateFormat;

public class TimeFormat {
	public SimpleDateFormat SetTimeFormat(){
		SimpleDateFormat  sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		return  sdf;
	}

}
