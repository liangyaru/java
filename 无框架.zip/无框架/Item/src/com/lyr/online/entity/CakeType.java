package com.lyr.online.entity;

public class CakeType {

	private int tnum;
	private String name;
	private int state;
	private int prenum;
	public int getTnum() {
		return tnum;
	}
	public void setTnum(int tnum) {
		this.tnum = tnum;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPrenum() {
		return prenum;
	}
	public void setPrenum(int prenum) {
		this.prenum = prenum;
	}
	public int getState() {
		return state;
	}
	public void setState(int state) {
		this.state = state;
	}
	
	
}
