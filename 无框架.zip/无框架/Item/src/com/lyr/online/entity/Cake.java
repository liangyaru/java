package com.lyr.online.entity;

public class Cake {
	private int cnum;
	private String name;
	private String description;
	private int size;
	private int price;
	private int discount;
	private String bigpic;
	private String smallpic1;
	private String smallpic2;
	private String smallpic3;
	private int star;
	private String tag;
	private int type;
	public int getCnum() {
		return cnum;
	}
	public void setCnum(int cnum) {
		this.cnum = cnum;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getDiscount() {
		return discount;
	}
	public void setDiscount(int discount) {
		this.discount = discount;
	}
	public String getBigpic() {
		return bigpic;
	}
	public void setBigpic(String bigpic) {
		this.bigpic = bigpic;
	}
	public String getSmallpic1() {
		return smallpic1;
	}
	public void setSmallpic1(String smallpic1) {
		this.smallpic1 = smallpic1;
	}
	public String getSmallpic2() {
		return smallpic2;
	}
	public void setSmallpic2(String smallpic2) {
		this.smallpic2 = smallpic2;
	}
	public String getSmallpic3() {
		return smallpic3;
	}
	public void setSmallpic3(String smallpic3) {
		this.smallpic3 = smallpic3;
	}
	public int getStar() {
		return star;
	}
	public void setStar(int star) {
		this.star = star;
	}
	public String getTag() {
		return tag;
	}
	public void setTag(String tag) {
		this.tag = tag;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	
}
